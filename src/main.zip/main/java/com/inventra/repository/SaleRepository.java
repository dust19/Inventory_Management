package com.inventra.repository;

import com.inventra.entity.Sale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface SaleRepository extends JpaRepository<Sale, Long> {
    List<Sale> findBySoldByIdOrderBySaleDateDesc(Long soldById);

    @Query("""
    SELECT s
    FROM Sale s
    JOIN Staff st ON st.user.id = s.soldBy.id
    WHERE st.manager.id = :managerId
    ORDER BY s.saleDate DESC
""")
    List<Sale> findSalesByManagerId(Long managerId);
}